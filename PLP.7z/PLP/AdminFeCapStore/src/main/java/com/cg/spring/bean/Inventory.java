package com.cg.spring.bean;

public class Inventory {

	private int id;
	private String name;
	private int count;
	private String merchantEmail;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public Inventory(int id, String name, int count, String merchantEmail) {
		super();
		this.id = id;
		this.name = name;
		this.count = count;
		this.merchantEmail = merchantEmail;
	}
	
	
	public Inventory() {
		
	}
}
