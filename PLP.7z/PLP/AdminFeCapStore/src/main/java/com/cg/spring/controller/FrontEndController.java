package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.bean.Admin;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Inventory;
import com.cg.spring.bean.Merchant;

@RestController
public class FrontEndController {

	@RequestMapping("/customers")
	public ModelAndView show() {
		RestTemplate rt = new RestTemplate();
		List<Customer> list = rt.getForObject("http://localhost:7072/customer", ArrayList.class);
		return new ModelAndView("customer","cust",list);
		
		
}
	
	@RequestMapping("/merchants")
	public ModelAndView showMerchant() {
		RestTemplate rt = new RestTemplate();
		List<Merchant> list = rt.getForObject("http://localhost:7072/merchant", ArrayList.class);
		return new ModelAndView("merchant","merch",list);

}
	
	@RequestMapping("/inventory")
	public ModelAndView showInventory() {
		RestTemplate rt = new RestTemplate();
		List<Inventory> list = rt.getForObject("http://localhost:7072/inventory", ArrayList.class);
		return new ModelAndView("inventory","inv",list);

}
	@RequestMapping("/profile")
	public ModelAndView showAdmin() {
		RestTemplate rt = new RestTemplate();
		List<Admin> list = rt.getForObject("http://localhost:7072/admin", ArrayList.class);
		return new ModelAndView("profile","adm",list);
		
		
		
	}
}