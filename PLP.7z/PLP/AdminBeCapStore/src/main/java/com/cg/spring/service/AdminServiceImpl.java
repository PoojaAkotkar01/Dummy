package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Admin;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Inventory;
import com.cg.spring.bean.Merchant;
import com.cg.spring.repo.IAdminRepo;
import com.cg.spring.repo.ICustomerRepo;
import com.cg.spring.repo.IInventoryRepo;
import com.cg.spring.repo.IMerchantRepo;

@Service
public class AdminServiceImpl implements IAdminService {
	
	@Autowired
	ICustomerRepo custRepo;
	@Autowired
	IMerchantRepo merchantRepo;
	@Autowired
	IInventoryRepo inventoryRepo;
	
	@Autowired
	IAdminRepo adminRepo;
	@Override
	public List<Customer> showAllCustomers() {
		
		List<Customer> custList = new ArrayList<>();
		custRepo.findAll().forEach(custList::add);
		return custList;
	}
	@Override
	public List<Merchant> showAllMerchant() {
	
		List<Merchant> merchantList = new ArrayList<>();
		merchantRepo.findAll().forEach(merchantList::add);
		return merchantList;
	}
	@Override
	public List<Inventory> showAllInventory() {
		
		List<Inventory> inventoryList = new ArrayList<>();
		inventoryRepo.findAll().forEach(inventoryList::add);
		return inventoryList;
		
	}
	@Override
	public List<Admin> showAdminProfile() {
		
		List<Admin> adminList = new ArrayList<>();
		adminRepo.findAll().forEach(adminList::add);
		return adminList;
	}
	
	
	
}
