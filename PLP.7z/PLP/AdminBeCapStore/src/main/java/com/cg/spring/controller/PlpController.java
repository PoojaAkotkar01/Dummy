package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.bean.Admin;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Inventory;
import com.cg.spring.bean.Merchant;
import com.cg.spring.service.IAdminService;


@RestController
public class PlpController {

	@Autowired
	IAdminService service;
	
	@RequestMapping("/customer")
	public List<Customer> showAllCustomers(){
		
		return service.showAllCustomers();
	}
	
	@RequestMapping("/merchant")
	public List<Merchant>showAllMerchant(){
		
		return service.showAllMerchant();
	}
	
	@RequestMapping("/inventory")
	public List<Inventory> showAllInventory(){
		
		return service.showAllInventory();
	}
	
	@RequestMapping("/admin")
	public List<Admin> showAdmin(){
		
		return service.showAdminProfile();
	}
}
