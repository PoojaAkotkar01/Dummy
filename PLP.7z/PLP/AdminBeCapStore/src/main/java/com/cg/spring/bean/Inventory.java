package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Inventory {

	@Id
	@Column(name="product_id")
	
	private int id;
	@Column(name="product_name")
	private String name;
	@Column(name="product_count")
	private int count;
	@Column(name="merchant_email")
	private String merchantEmail;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public Inventory(int id, String name, int count, String merchantEmail) {
		super();
		this.id = id;
		this.name = name;
		this.count = count;
		this.merchantEmail = merchantEmail;
	}
	
	public Inventory() {
	
	}
}
