package com.cg.spring.service;

import java.util.List;

import com.cg.spring.bean.Admin;
import com.cg.spring.bean.Customer;
import com.cg.spring.bean.Inventory;
import com.cg.spring.bean.Merchant;

public interface IAdminService {

	public List<Customer> showAllCustomers();
	public List<Merchant> showAllMerchant();
	public List<Inventory> showAllInventory();
	public List<Admin> showAdminProfile();
}
