package com.cg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginBean {

	@FindBy(how=How.NAME,name="userName")
	private WebElement uname;
	
	@FindBy(how=How.NAME,name="userPwd")
	private WebElement password;
	
	@FindBy(how=How.ID,id="btnlogin")
	private WebElement login;
	
	
	public void clickLogin() {
		login.click();
	}


	public String getUname() {
		return uname.getAttribute("value");
	}


	public void setUname(String name) {
		this.uname.sendKeys(name);
	}


	public String getPassword() {
		return password.getAttribute("value");
	}


	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	
}
