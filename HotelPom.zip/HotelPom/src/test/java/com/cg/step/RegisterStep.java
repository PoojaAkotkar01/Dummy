package com.cg.step;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.LoginBean;
import com.cg.pojo.RegisterBean;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStep {

	private WebDriver driver;
	private LoginBean loginBean;
	private RegisterBean registerBean;
	DriverUtil util=new DriverUtil();
	@Test
	public void test() throws Throwable {
		user_is_on_login_page();
		when_user_enters_username_and_password();
		user_is_navigated_to_registration_page();	
		when_user_enters_proper_details();
		user_is_successfully_registered();
		
	}
	
	@Before
	public void initialize() {

		driver=util.initiateDriver("Chrome");
		driver.manage().window().maximize();	
		loginBean=new LoginBean();
		PageFactory.initElements(driver, loginBean);
		registerBean = new RegisterBean();
		PageFactory.initElements(driver, registerBean);
		
	}
	
	@After
	public void stop() throws Exception {
		Thread.sleep(6000);
		driver.quit();
	}

	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
	  driver.get("C:\\Users\\Toshiba\\Documents\\workspace-sts-3.9.4.RELEASE\\HotelPom\\WebContent\\login.html"); 
	}

	@When("^when user enters username and password$")
	public void when_user_enters_username_and_password() throws Throwable {
	    loginBean.setUname("capgemini");
	    loginBean.setPassword("capg1234");
	}

	@Then("^user is navigated to registration page$")
	public void user_is_navigated_to_registration_page() throws Throwable {
	    loginBean.clickLogin();
	}

	@When("^when user enters proper details$")
	public void when_user_enters_proper_details() throws Throwable {
	  registerBean.setFirstName("pooja");
	  registerBean.setLastName("akotkar");
	  registerBean.setEmail("abc@gmail.com");
	  registerBean.setPhone("9876543210");
	  registerBean.setAddress("plot no 30 indra nagar");
	  registerBean.setCity("Pune");
	  registerBean.setState("Maharashtra");
	  registerBean.setPersons("2");
	  registerBean.setCardHolderName("pooja");
	  registerBean.setDebitNumber("12345");
	  registerBean.setCvv("111");
	  registerBean.setExMon("10");
	  registerBean.setExYear("2020");
	  
	}

	@Then("^user is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	    registerBean.confirm();
	}


}
